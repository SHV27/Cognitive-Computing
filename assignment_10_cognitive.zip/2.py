import re
import nltk
from nltk.tokenize import RegexpTokenizer
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer, WordNetLemmatizer

for pkg in ('punkt','stopwords','wordnet'):
    nltk.download(pkg, quiet=True)

text = "I enjoy exploring new technology. Innovations like AI and blockchain are changing the world. These tools simplify complex tasks and open new opportunities. Learning about tech trends is both fun and useful. The future of technology is fast and exciting."

clean = re.sub(r'[^a-zA-Z\s]', '', text.lower())
tokenizer = RegexpTokenizer(r'\w+')
tokens = tokenizer.tokenize(clean)
filtered = [t for t in tokens if t not in stopwords.words('english')]
stemmer = PorterStemmer()
lemmatizer = WordNetLemmatizer()
stemmed = [stemmer.stem(t) for t in filtered]
lemmatized = [lemmatizer.lemmatize(t) for t in filtered]
print(stemmed)
print(lemmatized)
