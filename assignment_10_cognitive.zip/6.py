from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.models import Sequential
from keras.layers import Embedding, LSTM, Dense
import numpy as np

text = "Training data consists of input-output pairs, where the input, known as \"features\" or \"predictors\", is matched with an output referred to as a \"label\" or \"target\". These datasets contain various types of information - from images and text to numerical values and sensor readings."

tokenizer = Tokenizer()
tokenizer.fit_on_texts([text])
seq = tokenizer.texts_to_sequences([text])[0]
input_seq = [seq[:i+1] for i in range(1, len(seq))]
max_len = max(len(x) for x in input_seq)
input_seq = pad_sequences(input_seq, maxlen=max_len, padding='pre')
X, y = input_seq[:, :-1], input_seq[:, -1]
vocab = len(tokenizer.word_index) + 1

model = Sequential([
    Embedding(vocab, 50, input_length=max_len-1),
    LSTM(100),
    Dense(vocab, activation='softmax')
])
model.compile('adam', 'sparse_categorical_crossentropy')
model.fit(X, y, epochs=100, verbose=1)

seed_seq = pad_sequences(tokenizer.texts_to_sequences(["sun"]), maxlen=max_len-1, padding='pre')
pred = model.predict(seed_seq, verbose=0)
print(tokenizer.index_word[np.argmax(pred)])
