import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def jaccard(a,b):
    a_set = set(re.findall(r'\w+', a.lower()))
    b_set = set(re.findall(r'\w+', b.lower()))
    return len(a_set & b_set) / len(a_set | b_set)

def cosine(a,b):
    vec = TfidfVectorizer()
    tfidf = vec.fit_transform([a,b])
    return cosine_similarity(tfidf)[0,1]

text1 = "Artificial Intelligence is revolutionizing industries with automation and data-driven decisions."
text2 = "Blockchain ensures data security and decentralization across various systems."

print(jaccard(text1, text2))
print(cosine(text1, text2))
