import re
import nltk
from nltk.tokenize import RegexpTokenizer, sent_tokenize
from nltk.corpus import stopwords
from nltk import FreqDist

for pkg in ('punkt','stopwords'):
    nltk.download(pkg, quiet=True)

text = "Artificial intelligence (AI) refers to the ability of machines to perform tasks that typically require human intelligence, such as learning, problem-solving, and decision-making. It's a broad field encompassing various technologies, including machine learning, deep learning, and natural language processing. AI systems can analyze data, identify patterns, make predictions, and even generate creative content"

clean = re.sub(r'[^\w\s]', '', text.lower())
tokenizer = RegexpTokenizer(r'\w+')
words_split = clean.split()
words_tokenized = tokenizer.tokenize(clean)
sentences = sent_tokenize(text)
filtered = [w for w in words_tokenized if w not in stopwords.words('english')]
freq = FreqDist(filtered)
print(sentences)
print(words_split)
print(words_tokenized)
print(filtered)
print(freq)
