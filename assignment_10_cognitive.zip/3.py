from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer

texts = [
    "The camera quality of this phone is outstanding and battery lasts long.",
    "This smartwatch has a sleek design and great performance.",
    "I am happy with the laptop speed and its lightweight body."
]

cv = CountVectorizer(stop_words='english')
bow = cv.fit_transform(texts)
print(cv.get_feature_names_out())
print(bow.toarray())

tfidf = TfidfVectorizer(stop_words='english')
mat = tfidf.fit_transform(texts)
print(tfidf.get_feature_names_out())
print(mat.toarray())

for i, row in enumerate(mat.toarray()):
    top3 = sorted(zip(tfidf.get_feature_names_out(), row), key=lambda x: x[1], reverse=True)[:3]
    print([k for k,_ in top3])
