from textblob import TextBlob
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from wordcloud import WordCloud
import matplotlib.pyplot as plt

reviews = [
    "I like this product, it's amazing!",
    "The product is terrible, do not buy it.",
    "It's okay, nothing special, just average."
]

analyzer = SentimentIntensityAnalyzer()
polarity = [TextBlob(r).sentiment.polarity for r in reviews]
labels = ['Positive' if p>0.1 else 'Negative' if p<-0.1 else 'Neutral' for p in polarity]
positive_reviews = [r for r,l in zip(reviews, labels) if l=='Positive']

for r,l in zip(reviews, labels):
    print(l, TextBlob(r).sentiment.polarity)

wordcloud = WordCloud().generate(" ".join(positive_reviews))
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis('off')
plt.show()
