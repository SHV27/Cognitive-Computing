import random
for _ in range(5):
    print(random.randint(50, 200))
