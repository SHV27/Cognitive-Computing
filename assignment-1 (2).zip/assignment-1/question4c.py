total = 0
for i in range(50, 151):
    total += i
print(total)
