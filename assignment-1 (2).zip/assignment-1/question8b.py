try:
    n = int(input("Type a number: "))
    print(n)
except ValueError:
    print("Oops! That’s not a valid number.")
