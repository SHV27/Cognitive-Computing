i = 7
while i < 17:
    print(i)
    i += 1
