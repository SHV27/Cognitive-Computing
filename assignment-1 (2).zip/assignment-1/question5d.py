first_dict = {"A": 1, "B": 2, "C": 3}
second_dict = {"X": 24, "Y": 25, "Z": 26}
combined = {**first_dict, **second_dict}
print(combined)
