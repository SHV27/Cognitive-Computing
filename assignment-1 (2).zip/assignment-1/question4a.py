for i in range(5, 16):
    print(i)
