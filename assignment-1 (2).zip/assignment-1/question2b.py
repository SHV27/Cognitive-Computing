text1 = "hello "
text2 = "world"
print(text1 + text2)