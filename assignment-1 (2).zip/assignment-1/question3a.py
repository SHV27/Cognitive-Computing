num = int(input("Enter a number: "))
if num > 0:
    print("It's a positive number.")
elif num < 0:
    print("It's a negative number.")
else:
    print("It's zero.")
