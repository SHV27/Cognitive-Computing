x = int(input("Enter the first number: "))
y = int(input("Enter the second number: "))
total = x + y
print(f"The addition of {x} and {y} results in: {total}")
