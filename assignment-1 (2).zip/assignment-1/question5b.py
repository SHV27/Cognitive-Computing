my_dict = {"apple": 10, "banana": 20, "cherry": 30}
key = "banana"
value = my_dict.get(key)
print(value)
