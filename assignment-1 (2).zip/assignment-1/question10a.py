import sys

a = int(sys.argv[1])
b = int(sys.argv[2])
print("Sum:", a + b)
