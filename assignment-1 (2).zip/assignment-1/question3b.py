n = int(input("Type a number: "))
if n % 2 == 0:
    print("The number is even.")
else:
    print("The number is odd.")
