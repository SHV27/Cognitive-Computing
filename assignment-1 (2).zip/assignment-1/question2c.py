num = 12
print("This is my roll number:", num)
