import random

roll = random.randint(1, 6)
print("You got:", roll)
