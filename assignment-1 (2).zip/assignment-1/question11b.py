import datetime

print("Current date and time:", datetime.datetime.now())
